// Leader: Kevin Arevalo

/* Members: Marinel Ledesma
            Rachelle Balaoro
            Dan Michael Navarro  */ 


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


// Define Instructor class
class Instructor {
    private String id;
    private String lastName;
    private String firstName;
    private String middleName;
    private String address;
    private int age;
    private List<String> assignedSubjects;

    // Constructor for Instructor
    public Instructor(String lastName, String firstName, String middleName, String address, int age) {
        this.id = generateID("INS"); // Generate unique ID
        this.lastName = Upsmain.capitalizeFirstLetter(lastName);
        this.firstName = Upsmain.capitalizeFirstLetter(firstName);
        this.middleName = Upsmain.capitalizeFirstLetter(middleName);
        this.address = Upsmain.capitalizeFirstLetter(address);
        this.age = age;
        this.assignedSubjects = new ArrayList<>(); // Initialize assignedSubjects list
    }

    // Getter methods
    public String getId() {
        return id;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getAddress() {
        return address;
    }

    public int getAge() {
        return age;
    }

    // Setter methods
    public void setLastName(String lastName) {
        this.lastName = Upsmain.capitalizeFirstLetter(lastName);
    }

    public void setFirstName(String firstName) {
        this.firstName = Upsmain.capitalizeFirstLetter(firstName);
    }

    public void setMiddleName(String middleName) {
        this.middleName = Upsmain.capitalizeFirstLetter(middleName);
    }

    public void setAddress(String address) {
        this.address = Upsmain.capitalizeFirstLetter(address);
    }

    public void setAge(int age) {
        this.age = age;
    }

    // Add method to get assigned subjects
    public List<String> getAssignedSubjects() {
        return assignedSubjects;
    }
    
    // Generate unique ID for Instructor
    public String generateID(String prefix) {
        Random rand = new Random();
        int num = rand.nextInt(9000) + 1000;
        return prefix + "24-" + num; // Fixed "24" added to match the required format
    }

    public void assignSubject(Subject subject) {
        assignedSubjects.add(subject.getId());
    }
}


// Define Student class
class Student {
    private String id;
    private String lastName;
    private String firstName;
    private String middleName;
    private String address;
    private int age;
    private List<String> enrolledSubjects; // Add a list to store enrolled subjects

    // Constructor for Student
    public Student(String firstName, String middleName, String lastName, String address, int age) {
        this.id = generateID("ST"); // Generate unique ID
        this.firstName = Upsmain.capitalizeFirstLetter(firstName);
        this.middleName = middleName != null ? Upsmain.capitalizeFirstLetter(middleName) : null;
        this.lastName = Upsmain.capitalizeFirstLetter(lastName);
        this.address = Upsmain.capitalizeFirstLetter(address);
        this.age = age;
        this.enrolledSubjects = new ArrayList<>(); // Initialize enrolledSubjects list
    }

    // Getter methods
    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAddress() {
        return address;
    }

    public int getAge() {
        return age;
    }

    // Setter methods
    public void setLastName(String lastName) {
        this.lastName = Upsmain.capitalizeFirstLetter(lastName);
    }

    public void setFirstName(String firstName) {
        this.firstName = Upsmain.capitalizeFirstLetter(firstName);
    }

    public void setMiddleName(String middleName) {
        this.middleName = Upsmain.capitalizeFirstLetter(middleName);
    }

    public void setAddress(String address) {
        this.address = Upsmain.capitalizeFirstLetter(address);
    }

    public void setAge(int age) {
        this.age = age;
    }

    // Generate unique ID for Student
    public String generateID(String prefix) {
        Random rand = new Random();
        int num = rand.nextInt(9000) + 1000;
        return prefix + "24-" + num; // Fixed "24" added to match the required format
    }
    
    // Method to enroll subject to student
    public void enrollSubject(Subject subject) {
        enrolledSubjects.add(subject.getId());
    }

    // Method to get enrolled subjects
    public List<String> getEnrolledSubjects() {
        return enrolledSubjects;
    }
}

// Define Subject class
class Subject {
    private String id;
    private String title;
    private String description;

    // Constructor for Subject
    public Subject(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    // Getter methods
    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    // Setter Methods
    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

// Main class
public class Upsmain {
    private static List<Instructor> instructors = new ArrayList<>();
    private static List<Student> students = new ArrayList<>();
    private static List<Subject> subjects = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    // Main method
    public static void main(String[] args) {
        // Main menu loop
        while (true) {
            System.out.println("\n\"Welcome to Universal Profiling System\"");

            // Display main menu options
            System.out.println("\n1. ADD Instructor");
            System.out.println("2. ADD Student");
            System.out.println("3. ADD/ASSIGN Subject");
            System.out.println("4. SEARCH Student/Instructor");
            System.out.println("5. View Student/Instructor info");
            System.out.println("6. View Student/Instructor subject");
            System.out.println("7. Exit");
            System.out.println("\n(Choose between 1-7)");
            System.out.print("Type Here: ");

            String input = scanner.nextLine(); // Read user input as string
            int choice;

            try {
                choice = Integer.parseInt(input); // Attempt to parse input as integer
            } catch (NumberFormatException e) {
                System.out.println("\n--------------------------------------");
                System.out.println("Invalid input. Please choose again.");
                System.out.println("--------------------------------------\n");
                continue; // Restart loop if input is not a number
            }

            // Switch statement to handle menu choices
            switch (choice) {
                case 1:
                    addInstructor();
                    break;
                case 2:
                    addStudent();
                    break;
                case 3:
                    addOrAssignSubject();
                    break;
                case 4:
                    searchStudentInstructor();
                    break;
                case 5:
                    viewStudentInstructorInfo();
                    break;
                case 6:
                    viewStudentInstructorSubject();
                    break;
                case 7:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("\n--------------------------------------");
                    System.out.println("Invalid input. Please choose again.");
                    System.out.println("--------------------------------------\n");
            }
        }
    }


    // Method to add an instructor
    private static void addInstructor() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected Add Instructor.");
        System.out.println("Please complete the details carefully.\n");

        String lastName = enterName("Last Name");
        String firstName = enterName("First Name");
        String middleName = enterMiddleName();
        String address = enterAddress();
        int age = enterAge();

        Instructor instructor = new Instructor(lastName, firstName, middleName, address, age);
        instructors.add(instructor);
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("Instructor added successfully with ID: " + instructor.getId());
        System.out.println("You can view this in View Student/Instructor Info (Main Menu) > View Insructor Info.\n");

        // Prompt to return to main menu or exit
        System.out.println("(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");

        String input;
        do {
            System.out.print("Type Here: ");
            input = scanner.nextLine();
            if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            }
        } while (true);
    }

    // Method to enter name with error handling
    private static String enterName(String fieldName) {
        String name;
        do {
            System.out.print("Enter " + fieldName + ": ");
            name = scanner.nextLine().trim(); // Remove leading and trailing whitespace
            if (name.length() < 2) {
                System.out.print("Please enter a valid " + fieldName + " (at least 2 characters): ");
            } else if (!name.matches("[a-zA-Z]+")) {
                System.out.print("Invalid input. Please enter a valid " + fieldName + " (only alphabets allowed): ");
            }
        } while (name.length() < 2 || !name.matches("[a-zA-Z]+"));
        return capitalizeFirstLetter(name);
    }

    // Method to enter middle name (optional)
    private static String enterMiddleName() {
        System.out.print("Enter Middle Name (Optional, press Enter if you want to skip): ");
        String middleName = scanner.nextLine().trim(); // Remove leading and trailing whitespace
        return middleName.isEmpty() ? null : capitalizeFirstLetter(middleName);
    }

    // Method to enter address with error handling
    private static String enterAddress() {
        String address;
        do {
            System.out.print("Enter Address: ");
            address = scanner.nextLine().trim(); // Remove leading and trailing whitespace
            if (address.length() < 2) {
                System.out.print("Please enter a valid Address (at least 2 characters): ");
            }
        } while (address.length() < 2);
        return capitalizeFirstLetter(address);
    }

    // Method to enter age with error handling
    private static int enterAge() {
        int age;
        do {
            System.out.print("Enter Age: ");
            try {
                age = Integer.parseInt(scanner.nextLine().trim());
                if (age <= 0 || age < 24 || age >= 100) {
                    System.out.println("Invalid age. Age must be between 24 and 100 years.");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a valid Age (an integer): ");
                age = -1;
            }
        } while (age <= 0 || age < 24 || age >= 100);
        return age;
    }

    // Method to view instructor information
    private static void viewInstructorInfo() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected View Instructor Info.");

        // Display instructors
        System.out.println("\nInstructor/s Information:");
        if (instructors.isEmpty()) {
            System.out.println("N/A");
        } else {
            for (Instructor instructor : instructors) {
                System.out.println("ID: " + instructor.getId());
                System.out.println("Last Name: " + capitalizeFirstLetter(instructor.getLastName()));
                System.out.println("First Name: " + capitalizeFirstLetter(instructor.getFirstName()));
                System.out.println("Middle Name: " + (instructor.getMiddleName() != null ? capitalizeFirstLetter(instructor.getMiddleName()) : "N/A"));
                System.out.println("Address: " + capitalizeFirstLetter(instructor.getAddress()));
                System.out.println("Age: " + instructor.getAge());
                List<String> assignedSubjects = instructor.getAssignedSubjects();
                System.out.print("Assigned Subject/s: ");
                if (assignedSubjects.isEmpty()) {
                    System.out.println("None");
                } else {
                    for (int i = 0; i < assignedSubjects.size(); i++) {
                        String subjectId = assignedSubjects.get(i);
                        // Find the subject object with the matching ID
                        Subject subject = null;
                        for (Subject sub : subjects) {
                            if (sub.getId().equals(subjectId)) {
                                subject = sub;
                                break;
                            }
                        }
                        if (subject != null) {
                            System.out.print(subject.getId() + " | " + subject.getTitle());
                            if (i < assignedSubjects.size() - 1) {
                                System.out.print(", ");
                            }
                        }
                    }
                    System.out.println();
                }
                System.out.println();
            }
        }

        // Prompt to enter instructor ID for editing or returning to the main menu
        System.out.println("===========================================================================\n");
        System.out.println("Enter the ID of the Instructor to perform edit or delete.");
        System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");

        String instructorId;
        do {
            instructorId = scanner.nextLine();

            if (instructorId.equals("0")) {
                return; // Return to main menu
            } else if (instructorId.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                // Find the instructor by ID
                Instructor selectedInstructor = null;
                for (Instructor instructor : instructors) {
                    if (instructor.getId().equalsIgnoreCase(instructorId)) {
                        selectedInstructor = instructor;
                        break;
                    }
                }

                if (selectedInstructor != null) {
                    // Display the selected instructor's information
                    System.out.println("\n----------------------------------------------------------------------------");
                    System.out.println("You selected " + selectedInstructor.getId() + " | " + selectedInstructor.getLastName() + ", " + selectedInstructor.getFirstName() + ".");
                    System.out.println("\nInstructor Information:");
                    System.out.println("Last Name: " + capitalizeFirstLetter(selectedInstructor.getLastName()));
                    System.out.println("First Name: " + capitalizeFirstLetter(selectedInstructor.getFirstName()));
                    System.out.println("Middle Name: " + (selectedInstructor.getMiddleName() != null ? capitalizeFirstLetter(selectedInstructor.getMiddleName()) : "N/A"));
                    System.out.println("Address: " + capitalizeFirstLetter(selectedInstructor.getAddress()));
                    System.out.println("Age: " + selectedInstructor.getAge());
                    System.out.println("Assigned Subject/s: ");
                    List<String> assignedSubjects = selectedInstructor.getAssignedSubjects();
                    if (assignedSubjects.isEmpty()) {
                        System.out.println("None");
                    } else {
                        for (String subjectId : assignedSubjects) {
                            // Find the subject object with the matching ID
                            Subject subject = findSubjectById(subjectId);
                            if (subject != null) {
                                System.out.println(subject.getId() + " | " + subject.getTitle());
                            }
                        }
                    }

                    // Prompt to edit or delete the selected instructor
                    System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
                    System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
                    System.out.print("Type Here: ");
                    String choice = scanner.nextLine();

                    switch (choice.toUpperCase()) {
                        case "E":
                            // Edit the instructor's information
                            editInstructor(selectedInstructor);
                            break;
                        case "D":
                            deleteInstructor(selectedInstructor);
                            break;
                        case "0":
                            return; // Return to main menu
                        case "EXIT":
                            System.out.println("Exiting...");
                            System.exit(0); // Exit the program
                        default:
                            System.out.println("Invalid input.");
                    }
                } else {
                    System.out.println("Instructor with ID " + instructorId + " not found. Please try again.");
                    System.out.print("Type Here: ");
                }
            }
        } while (true);
    }

    // Method to edit instructor information
    private static void editInstructor(Instructor instructor) {
        while (true) {
            System.out.println("\n----------------------------------------------------------------------------");
            System.out.println("You selected edit.\n");

            // Prompt user to enter new information
            String newLastName = enterName("new Last Name");
            String newFirstName = enterName("new First Name");
            String newMiddleName = enterMiddleName();
            String newAddress = enterAddress();
            int newAge = enterAge();

            // Update instructor's information
            instructor.setLastName(newLastName);
            instructor.setFirstName(newFirstName);
            instructor.setMiddleName(newMiddleName);
            instructor.setAddress(newAddress);
            instructor.setAge(newAge);

            // Display updated information
            System.out.println("\n----------------------------------------------------------------------------");
            System.out.println("You successfully edited Instructor.\n");
            System.out.println("Last Name: " + capitalizeFirstLetter(newLastName));
            System.out.println("First Name: " + capitalizeFirstLetter(newFirstName));
            System.out.println("Middle Name (Optional, press Enter if you want to skip): " + (newMiddleName != null ? capitalizeFirstLetter(newMiddleName) : "N/A"));
            System.out.println("Address: " + capitalizeFirstLetter(newAddress));
            System.out.println("Age: " + newAge);

            // Prompt to return to main menu or exit
            System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
            System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
            System.out.print("Type Here: ");

            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("E") || input.equalsIgnoreCase("D")) {
                // If the input is valid (E or D), break the loop to proceed
                break;
            } else if (input.equals("0")) {
                // If the input is 0, return to the main menu
                return;
            } else if (input.equalsIgnoreCase("exit")) {
                // If the input is "exit", exit the program
                System.out.println("Exiting...");
                System.exit(0);
            } else {
                // If the input is invalid, display an error message and continue the loop
                System.out.println("Invalid input.");
            }
        }
    }

    // Method to delete instructor information
    private static void deleteInstructor(Instructor instructor) {
        // Remove the instructor from the list
        instructors.remove(instructor);
        
        // Display a confirmation message
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("Instructor deleted successfully.\n");
        
        // Prompt to return to main menu or exit
        System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
        System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");
    }


     // Method to add student
     private static void addStudent() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected Add Student.");
        System.out.println("Please complete the details carefully.\n");

        String lastName = enterName("Last Name");
        String firstName = enterName("First Name");
        String middleName = enterMiddleName();
        String address = enterAddress();
        int age = enterStudentAge();

        Student student = new Student(firstName, middleName, lastName, address, age);
        students.add(student);
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("Student added successfully with ID: " + student.getId());
        System.out.println("You can view this in View Student/Instructor info (Main Menu) > View Student Info.\n");

        // Prompt to return to main menu or exit
        System.out.println("(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");

        String input;
        do {
            System.out.print("Type Here: ");
            input = scanner.nextLine();
            if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            }
        } while (true);
    }

    // Method to enter age with error handling for student
    private static int enterStudentAge() {
        int age;
        do {
            System.out.print("Enter Age: ");
            try {
                age = Integer.parseInt(scanner.nextLine().trim());
                if (age <= 0 || age < 17 || age >= 100) {
                    System.out.println("Invalid age. Age must be between 17 and 100 years.");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a valid Age (an integer): ");
                age = -1;
            }
        } while (age <= 0 || age < 17 || age >= 100);
        return age;
    }

    // Method to view student information
    private static void viewStudentInfo() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected View Student Info.");

        // Display students
        System.out.println("\nStudent/s Information:");
        if (students.isEmpty()) {
            System.out.println("N/A");
        } else {
            for (Student student : students) {
                System.out.println("ID: " + student.getId());
                System.out.println("Last Name: " + capitalizeFirstLetter(student.getLastName()));
                System.out.println("First Name: " + capitalizeFirstLetter(student.getFirstName()));
                System.out.println("Middle Name: " + (student.getMiddleName() != null ? capitalizeFirstLetter(student.getMiddleName()) : "N/A"));
                System.out.println("Address: " + capitalizeFirstLetter(student.getAddress()));
                System.out.println("Age: " + student.getAge());

                // Display enrolled subjects
                List<String> enrolledSubjects = student.getEnrolledSubjects();
                System.out.print("Enrolled Subject/s: ");
                if (enrolledSubjects.isEmpty()) {
                    System.out.println("N/A");
                } else {
                    for (int i = 0; i < enrolledSubjects.size(); i++) {
                        String subjectId = enrolledSubjects.get(i);
                        // Find the subject object with the matching ID
                        Subject subject = findSubjectById(subjectId);
                        if (subject != null) {
                            System.out.print(subject.getId() + " | " + subject.getTitle());
                            if (i < enrolledSubjects.size() - 1) {
                                System.out.print(", ");
                            }
                        }
                    }
                }

                System.out.println();
                System.out.println();
            }
        }

        // Prompt to enter student ID for editing or returning to the main menu
        System.out.println("===========================================================================\n");
        System.out.println("Enter the ID of the Student to perform edit or delete.");
        System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");

        String studentId;
        do {
            studentId = scanner.nextLine();

            if (studentId.equals("0")) {
                return; // Return to main menu
            } else if (studentId.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                // Find the student by ID
                Student selectedStudent = null;
                for (Student student : students) {
                    if (student.getId().equalsIgnoreCase(studentId)) {
                        selectedStudent = student;
                        break;
                    }
                }

                if (selectedStudent != null) {
                    // Display the selected student's information
                    System.out.println("\n----------------------------------------------------------------------------");
                    System.out.println("You selected " + selectedStudent.getId() + " | " + selectedStudent.getLastName() + ", " + selectedStudent.getFirstName() + ".");
                    System.out.println("\nStudent Information:");
                    System.out.println("Last Name: " + capitalizeFirstLetter(selectedStudent.getLastName()));
                    System.out.println("First Name: " + capitalizeFirstLetter(selectedStudent.getFirstName()));
                    System.out.println("Middle Name: " + (selectedStudent.getMiddleName() != null ? capitalizeFirstLetter(selectedStudent.getMiddleName()) : "N/A"));
                    System.out.println("Address: " + capitalizeFirstLetter(selectedStudent.getAddress()));
                    System.out.println("Age: " + selectedStudent.getAge());
                    System.out.println("Enrolled Subject/s: ");
                    List<String> enrolledSubjects = selectedStudent.getEnrolledSubjects();
                    if (enrolledSubjects.isEmpty()) {
                        System.out.println("N/A");
                    } else {
                        for (String subjectId : enrolledSubjects) {
                            // Find the subject object with the matching ID
                            Subject subject = findSubjectById(subjectId);
                            if (subject != null) {
                                System.out.println(subject.getId() + " | " + subject.getTitle());
                            }
                        }
                    }

                    // Prompt to edit or delete the selected student
                    System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
                    System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
                    System.out.print("Type Here: ");
                    String choice = scanner.nextLine();

                    switch (choice.toUpperCase()) {
                        case "E":
                            // Edit the student's information
                            editStudent(selectedStudent);
                            break;
                        case "D":
                            deleteStudent(selectedStudent);
                            break;
                        case "0":
                            return; // Return to main menu
                        case "EXIT":
                            System.out.println("Exiting...");
                            System.exit(0); // Exit the program
                        default:
                            System.out.println("Invalid input.");
                    }
                } else {
                    System.out.println("Student with ID " + studentId + " not found. Please try again.");
                    System.out.print("Type Here: ");
                }
            }
        } while (true);
    }

    // Method to edit student information
    private static void editStudent(Student student) {
        while (true) {
            System.out.println("\n----------------------------------------------------------------------------");
            System.out.println("You selected edit.\n");

            // Prompt user to enter new information
            String newLastName = enterName("new Last Name");
            String newFirstName = enterName("new First Name");
            String newMiddleName = enterMiddleName();
            String newAddress = enterAddress();
            int newAge = enterAge();

            // Update student's information
            student.setLastName(newLastName);
            student.setFirstName(newFirstName);
            student.setMiddleName(newMiddleName);
            student.setAddress(newAddress);
            student.setAge(newAge);

            // Display updated information
            System.out.println("\n----------------------------------------------------------------------------");
            System.out.println("You successfully edited Student.\n");
            System.out.println("Last Name: " + capitalizeFirstLetter(newLastName));
            System.out.println("First Name: " + capitalizeFirstLetter(newFirstName));
            System.out.println("Middle Name (Optional, press Enter if you want to skip): " + (newMiddleName != null ? capitalizeFirstLetter(newMiddleName) : "N/A"));
            System.out.println("Address: " + capitalizeFirstLetter(newAddress));
            System.out.println("Age: " + newAge);

            // Prompt to return to main menu or exit
            System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
            System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
            System.out.print("Type Here: ");

            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("E") || input.equalsIgnoreCase("D")) {
                // If the input is valid (E or D), break the loop to proceed
                break;
            } else if (input.equals("0")) {
                // If the input is 0, return to the main menu
                return;
            } else if (input.equalsIgnoreCase("exit")) {
                // If the input is "exit", exit the program
                System.out.println("Exiting...");
                System.exit(0);
            } else {
                // If the input is invalid, display an error message and continue the loop
                System.out.println("Invalid input.");
            }
        }
    }

    // Method to delete student information
    private static void deleteStudent(Student student) {
        // Remove the student from the list
        students.remove(student);
        
        // Display a confirmation message
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("Student deleted successfully.\n");
        
        // Prompt to return to main menu or exit
        System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
        System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");
    }


    // Method to add or assign a subject
    private static void addOrAssignSubject() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected Add/Assign Subject.\n");
        System.out.println("Choose between 1 and 3:");
        System.out.println("1. ADD Subject");
        System.out.println("2. ASSIGN Subject to Instructor");
        System.out.println("3. ADD Subject to Student");

        // Prompt to return to main menu or exit
        System.out.println("\n(Note: You can enter \"0\" to return to Main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");

        String input;
        do {
            input = scanner.nextLine();
            switch (input) {
                case "1":
                addSubject();
                    break;
                case "2":
                   assignSubjectToInstructor();
                    break;
                case "3":
                    enrollSubjectToStudent();
                case "0":
                    return; // Return to main menu
                case "exit":
                    System.out.println("Exiting...");
                    System.exit(0); // Exit the program
                default:
                    System.out.println("\n\n----------------------------------------------------------------------------");
                    System.out.println("You selected Add/Assign Subject.\n");
                    System.out.println("Choose between 1 and 3:");
                    System.out.println("1. ADD Subject");
                    System.out.println("2. ASSIGN Subject to Instructor");
                    System.out.println("3. ADD Subject to Student");
                    System.out.println("\n(Note: You can enter \"0\" to return to Main menu, type \"exit\" to end the program)");
                    System.out.print("Type Here: ");
            }
        } while (!input.equals("1") && !input.equals("2"));
    }

    // Method to add subject
    private static void addSubject() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected ADD Subject.");
        System.out.println("Please complete the details carefully.\n");

        String title = enterSubjectTitle();
        String description = enterSubjectDescription();
        String subjectId = generateSubjectID();

        subjects.add(new Subject(subjectId, title, description));

        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("Subject added successfully with ID: " + subjectId);
        System.out.println("You can ASSIGN/ADD this to the Instructor/Student Subject.\n");

        // Prompt to return to main menu or exit
        System.out.println("(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");

        String input;
        do {
            System.out.print("Type Here: ");
            input = scanner.nextLine();
            if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                System.out.println("\nInvalid input. Please enter 0 to return to main menu, or type \"exit\" to exit.");
            }
        } while (true);
    }

    // Method to enter subject title with error handling
    private static String enterSubjectTitle() {
        String title;
        do {
            System.out.print("Enter Subject Title: ");
            title = scanner.nextLine().trim();
            if (title.length() < 2 || title.matches(".*\\d.*")) {
                System.out.println("Invalid input. Subject title must be at least 2 characters long and contain only letters.");
            }
        } while (title.length() < 2 || title.matches(".*\\d.*"));
        return title;
    }

    // Method to enter subject description with error handling
    private static String enterSubjectDescription() {
        String description;
        do {
            System.out.print("Enter Subject Description: ");
            description = scanner.nextLine().trim();
            if (description.isEmpty()) {
                System.out.println("Invalid input. Subject description cannot be empty.");
            }
        } while (description.isEmpty());
        return description;
    }

    // Method to generate a random subject ID
    private static String generateSubjectID() {
        Random rand = new Random();
        int num = rand.nextInt(9000) + 1000;
        return "SUB-" + num;
    }

    // Method to assign subject to instructor
    private static void assignSubjectToInstructor() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected ASSIGN Subject to Instructor.\n");
        
        // Display available subjects
        System.out.println("Available Subject/s:");
        if (subjects.isEmpty()) {
            System.out.println("N/A");
        } else {
            for (int i = 0; i < subjects.size(); i++) {
                System.out.println((i + 1) + ". " + subjects.get(i).getId() + " | " + subjects.get(i).getTitle());
            }
        }

        System.out.println("\nChoose a SUBJECT:");
        System.out.println("(Note: You can enter \"0\" to return to Main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");
        
        String input;
        do {
            input = scanner.nextLine();
            if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                try {
                    int subjectIndex = Integer.parseInt(input) - 1;
                    if (subjectIndex >= 0 && subjectIndex < subjects.size()) {
                        Subject selectedSubject = subjects.get(subjectIndex);
                        System.out.println("\n----------------------------------------------------------------------------");
                        System.out.println("ASSIGN IT TO: (Available Instructor/s)\n");

                        // Display available instructors
                        List<Instructor> availableInstructors = getAvailableInstructors(selectedSubject);
                        if (availableInstructors.isEmpty()) {
                            System.out.println("N/A");
                        } else {
                            for (int i = 0; i < availableInstructors.size(); i++) {
                                Instructor instructor = availableInstructors.get(i);
                                System.out.println((i + 1) + ". " + instructor.getId() + " | " + instructor.getLastName() + ", " + instructor.getFirstName());
                            }
                        }

                        System.out.println("\nChoose a Instructor:");
                        System.out.println("(Note: You can enter \"0\" to return to Main menu, type \"exit\" to end the program)");
                        System.out.print("Type Here: ");
                        
                        do {
                            input = scanner.nextLine();
                            if (input.equals("0")) {
                                return; // Return to main menu
                            } else if (input.equalsIgnoreCase("exit")) {
                                System.out.println("Exiting...");
                                System.exit(0); // Exit the program
                            } else {
                                try {
                                    int instructorIndex = Integer.parseInt(input) - 1;
                                    if (instructorIndex >= 0 && instructorIndex < availableInstructors.size()) {
                                        Instructor selectedInstructor = availableInstructors.get(instructorIndex);
                                        // Assign subject to instructor
                                        selectedInstructor.assignSubject(selectedSubject);
                                        System.out.println("\n----------------------------------------------------------------------------");
                                        System.out.println("You have successfully assigned the Subject to the Instructor.");
                                        System.out.println("You can view this in View Student/Instructor subject > View Instructor Assigned Subject.\n");
                                        // Prompt to return to main menu or exit
                                        System.out.println("(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");
                                        do {
                                            System.out.print("Type Here: ");
                                            input = scanner.nextLine();
                                            if (input.equals("0")) {
                                                return; // Return to main menu
                                            } else if (input.equalsIgnoreCase("exit")) {
                                                System.out.println("Exiting...");
                                                System.exit(0); // Exit the program
                                            } else {
                                                System.out.println("\nInvalid input. Please enter 0 to return to main menu, or type \"exit\" to exit.");
                                            }
                                        } while (true);
                                    } else {
                                        System.out.println("\nInvalid input. Please choose a valid Instructor.");
                                        System.out.print("Type Here: ");
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("\nInvalid input. Please enter a valid number.");
                                    System.out.print("Type Here: ");
                                }
                            }
                        } while (true);
                    } else {
                        System.out.println("\nInvalid input. Please choose a valid subject.");
                        System.out.print("Type Here: ");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("\nInvalid input. Please enter a valid number.");
                    System.out.print("Type Here: ");
                }
            }
        } while (true);
    }

    // Method to get available instructors for a given subject
    private static List<Instructor> getAvailableInstructors(Subject subject) {
        List<Instructor> availableInstructors = new ArrayList<>();
        for (Instructor instructor : instructors) {
            if (!instructor.getAssignedSubjects().contains(subject.getId())) {
                availableInstructors.add(instructor);
            }
        }
        return availableInstructors;
    }

    // Method to enroll subject to student
    private static void enrollSubjectToStudent() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected ENROLL Subject to Student.\n");

        // Display available subjects
        System.out.println("Available Subject/s:");
        if (subjects.isEmpty()) {
            System.out.println("N/A");
        } else {
            for (int i = 0; i < subjects.size(); i++) {
                System.out.println((i + 1) + ". " + subjects.get(i).getId() + " | " + subjects.get(i).getTitle());
            }
        }

        System.out.println("\nChoose a SUBJECT:");
        System.out.println("(Note: You can enter \"0\" to return to Main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");

        String input;
        do {
            input = scanner.nextLine();
            if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                try {
                    int subjectIndex = Integer.parseInt(input) - 1;
                    if (subjectIndex >= 0 && subjectIndex < subjects.size()) {
                        Subject selectedSubject = subjects.get(subjectIndex);
                        System.out.println("\n----------------------------------------------------------------------------");
                        System.out.println("ENROLL IT TO: (Available Student/s)\n");

                        // Display available students
                        List<Student> availableStudents = getAvailableStudents(selectedSubject);
                        if (availableStudents.isEmpty()) {
                            System.out.println("N/A");
                        } else {
                            for (int i = 0; i < availableStudents.size(); i++) {
                                Student student = availableStudents.get(i);
                                System.out.println((i + 1) + ". " + student.getId() + " | " + student.getLastName() + ", " + student.getFirstName());
                            }
                        }

                        System.out.println("\nChoose a Student:");
                        System.out.println("(Note: You can enter \"0\" to return to Main menu, type \"exit\" to end the program)");
                        System.out.print("Type Here: ");

                        do {
                            input = scanner.nextLine();
                            if (input.equals("0")) {
                                return; // Return to main menu
                            } else if (input.equalsIgnoreCase("exit")) {
                                System.out.println("Exiting...");
                                System.exit(0); // Exit the program
                            } else {
                                try {
                                    int studentIndex = Integer.parseInt(input) - 1;
                                    if (studentIndex >= 0 && studentIndex < availableStudents.size()) {
                                        Student selectedStudent = availableStudents.get(studentIndex);
                                        // Enroll subject to student
                                        selectedStudent.enrollSubject(selectedSubject);
                                        System.out.println("\n----------------------------------------------------------------------------");
                                        System.out.println("You have successfully enrolled the Subject to the Student.");
                                        System.out.println("You can view this in View Student/Instructor subject > View Student Enrolled Subject.\n");
                                        // Prompt to return to main menu or exit
                                        System.out.println("(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");
                                        do {
                                            System.out.print("Type Here: ");
                                            input = scanner.nextLine();
                                            if (input.equals("0")) {
                                                return; // Return to main menu
                                            } else if (input.equalsIgnoreCase("exit")) {
                                                System.out.println("Exiting...");
                                                System.exit(0); // Exit the program
                                            } else {
                                                System.out.println("\nInvalid input. Please enter 0 to return to main menu, or type \"exit\" to exit.");
                                            }
                                        } while (true);
                                    } else {
                                        System.out.println("\nInvalid input. Please choose a valid Student.");
                                        System.out.print("Type Here: ");
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("\nInvalid input. Please enter a valid number.");
                                    System.out.print("Type Here: ");
                                }
                            }
                        } while (true);
                    } else {
                        System.out.println("\nInvalid input. Please choose a valid subject.");
                        System.out.print("Type Here: ");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("\nInvalid input. Please enter a valid number.");
                    System.out.print("Type Here: ");
                }
            }
        } while (true);
    }

    // Method to get available students for a given subject
    private static List<Student> getAvailableStudents(Subject subject) {
        List<Student> availableStudents = new ArrayList<>();
        for (Student student : students) {
            // Implement any logic here to check if student can enroll in this subject
            availableStudents.add(student);
        }
        return availableStudents;
    }


    // Method to view student and instructor information
    private static void searchStudentInstructor() {
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("You selected SEARCH Student/Instructor.\n");
    
        System.out.println("Search Instructor or Student.\n");
    
        // Display enrolled instructors
        System.out.println("Enrolled Instructor:");
        if (instructors.isEmpty()) {
            System.out.println("N/A");
        } else {
            int instructorIndex = 1;
            for (Instructor instructor : instructors) {
                System.out.println(instructorIndex + ". " + instructor.getId() + " | " + instructor.getLastName() + ", " + instructor.getFirstName());
                instructorIndex++;
            }
        }
    
        // Display enrolled students
        System.out.println("\nEnrolled Student:");
        if (students.isEmpty()) {
            System.out.println("N/A");
        } else {
            char studentLetter = 'a';
            for (Student student : students) {
                System.out.println(studentLetter + ". " + student.getId() + " | " + student.getLastName() + ", " + student.getFirstName());
                studentLetter++;
            }
        }
    
        // Choose the number of Instructor or Student to search
        System.out.println("\nChoose the number of Instructor or Student that you want to search.");
        System.out.println("(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");
        System.out.print("Type Here: ");
    
        String input;
        do {
            input = scanner.nextLine();
            if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                // Validate the input
                if (input.matches("[0-9]+")) { // Check if the input is a number
                    int index = Integer.parseInt(input) - 1;
                    if (index >= 0 && index < instructors.size()) {
                        viewInstructorDetails(instructors.get(index));
                        break;
                    } else if (index >= instructors.size() && index < instructors.size() + students.size()) {
                        viewStudentDetails(students.get(index - instructors.size()));
                        break;
                    } else {
                        System.out.println("Invalid input. Please choose a valid number or letter.");
                        System.out.print("Type Here: ");
                    }
                } else if (input.matches("[a-zA-Z]")) { // Check if the input is a letter
                    int studentIndex = input.toLowerCase().charAt(0) - 'a';
                    if (studentIndex >= 0 && studentIndex < students.size()) {
                        viewStudentDetails(students.get(studentIndex));
                        break;
                    } else {
                        System.out.println("Invalid input. Please choose a valid number or letter.");
                        System.out.print("Type Here: ");
                    }
                } else {
                    System.out.println("Invalid input. Please choose a valid number or letter.");
                    System.out.print("Type Here: ");
                }
            }
        } while (true);
    }
    

    // Method to view details of an instructor
    private static void viewInstructorDetails(Instructor instructor) {
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("You have searched " + instructor.getFirstName() + ", " + instructor.getLastName() + " (Instructor).\n");

        // Display instructor details
        System.out.println("Details:");
        System.out.println("Instructor/s Information:");
        System.out.println("ID: " + instructor.getId());
        System.out.println("Last Name: " + instructor.getLastName());
        System.out.println("First Name: " + instructor.getFirstName());
        System.out.println("Middle Name: " + (instructor.getMiddleName() != null ? instructor.getMiddleName() : "N/A"));
        System.out.println("Address: " + instructor.getAddress());
        System.out.println("Age: " + instructor.getAge());

        // Display assigned subjects
        List<String> assignedSubjects = instructor.getAssignedSubjects();
        System.out.println("Assigned Subject/s: ");
        if (assignedSubjects.isEmpty()) {
            System.out.println("None");
        } else {
            for (String subjectId : assignedSubjects) {
                Subject subject = findSubjectById(subjectId);
                if (subject != null) {
                    System.out.println(subject.getId() + " | " + subject.getTitle());
                    System.out.println("Subject Description: " + subject.getDescription());
                }
            }
        }

        // Prompt to search again or return to main menu
        System.out.println("\n\nEnter \"S\" if you want to search again.");
        System.out.println("(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");
        System.out.print("Type Here: ");
        String input;
        do {
            input = scanner.nextLine();
            if (input.equalsIgnoreCase("S")) {
                searchStudentInstructor(); // Search again
            } else if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                System.out.println("Invalid input. Please enter \"S\" to search again, 0 to return to main menu, or \"exit\" to exit.");
            }
        } while (true);
    }

    // Method to view details of a student
    private static void viewStudentDetails(Student student) {
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("You have searched " + student.getFirstName() + " " + student.getLastName() + " (Student).\n");

        // Display student details
        System.out.println("Details:");
        System.out.println("Student/s Information:");
        System.out.println("ID: " + student.getId());
        System.out.println("Last Name: " + student.getLastName());
        System.out.println("First Name: " + student.getFirstName());
        System.out.println("Middle Name: " + (student.getMiddleName() != null ? student.getMiddleName() : "N/A"));
        System.out.println("Address: " + student.getAddress());
        System.out.println("Age: " + student.getAge());

        // Display enrolled subjects
        List<String> enrolledSubjects = student.getEnrolledSubjects();
        System.out.println("Enrolled Subject/s: ");
        if (enrolledSubjects.isEmpty()) {
            System.out.println("N/A");
        } else {
            for (String subjectId : enrolledSubjects) {
                Subject subject = findSubjectById(subjectId);
                if (subject != null) {
                    System.out.println(subject.getId() + " | " + subject.getTitle());
                    System.out.println("Subject Description: " + subject.getDescription());
                }
            }
        }

        // Prompt to search again or return to main menu
        System.out.println("\n\nEnter \"S\" if you want to search again.");
        System.out.println("(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");
        System.out.print("Type Here: ");
        String input;
        do {
            input = scanner.nextLine();
            if (input.equalsIgnoreCase("S")) {
                searchStudentInstructor(); // Search again
            } else if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                System.out.println("Invalid input. Please enter \"S\" to search again, 0 to return to main menu, or \"exit\" to exit.");
            }
        } while (true);
    }


    // Method to find a subject by ID
    private static Subject findSubjectById(String id) {
        for (Subject subject : subjects) {
            if (subject.getId().equals(id)) {
                return subject;
            }
        }
        return null;
    }


    // Method to view student and instructor information
    private static void viewStudentInstructorInfo() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected View Student/Instructor info.");

        // Display menu options
        System.out.println("\nChoose between 1 and 2:");
        System.out.println("1. View Instructor Info");
        System.out.println("2. View Student Info");
        System.out.println("\n(Note: You can enter \"0\" to return to Main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");

        String input;
        do {
            input = scanner.nextLine();
            switch (input) {
                case "1":
                    viewInstructorInfo();
                    return;
                case "2":
                    viewStudentInfo();
                    return;
                case "0":
                    return; // Return to main menu
                case "exit":
                    System.out.println("Exiting...");
                    System.exit(0); // Exit the program
                default:
                    System.out.println("\nInvalid input. Please choose again.");
                    System.out.print("Type Here: ");
            }
        } while (!input.equals("1") && !input.equals("2"));
    }


    // Method to view subjects for students or instructors
    private static void viewStudentInstructorSubject() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected View Student/Instructor subject.\n");

        // Display menu options
        System.out.println("Choose between 1 and 2:");
        System.out.println("1. View Instructor subject");
        System.out.println("2. View Student subject");
        System.out.println("\n(Note: You can enter \"0\" to return to Main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");

        String input;
        do {
            input = scanner.nextLine();
            switch (input) {
                case "1":
                    viewInstructorSubjects();
                    return;
                case "2":
                    viewStudentSubjects();
                    return;
                case "0":
                    return; // Return to main menu
                case "exit":
                    System.out.println("Exiting...");
                    System.exit(0); // Exit the program
                default:
                    System.out.println("\nInvalid input. Please try again.");
                    System.out.print("Type Here: ");
            }
        } while (!input.equals("1") && !input.equals("2"));
    }


    // Method to view subjects assigned to instructors
    private static void viewInstructorSubjects() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected View Instructor subjects.\n");

        boolean subjectsFound = false;

        // Display assigned subjects for each instructor
        for (Instructor instructor : instructors) {
            if (!instructor.getAssignedSubjects().isEmpty()) {
                subjectsFound = true;
                System.out.println("Assigned subject to Instructor:");
                for (String subjectId : instructor.getAssignedSubjects()) {
                    // Find the subject object with the matching ID
                    Subject subject = findSubjectById(subjectId);
                    if (subject != null) {
                        System.out.println("Instructor ID: " + instructor.getId() + " | " + instructor.getLastName() + ", " + instructor.getFirstName());
                        System.out.println("Subject ID: " + subject.getId());
                        System.out.println("Subject Title: " + subject.getTitle());
                        System.out.println("Subject Description: " + subject.getDescription());
                        System.out.println("\n===========================================================================\n");
                    }
                }
            }
        }

        if (!subjectsFound) {
            System.out.println("No subjects assigned to any instructor.");
        }

        // Prompt to enter the ID of the Subject to perform edit or delete
        System.out.println("\n>Enter the ID of the Subject to perform edit or delete.");
        System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");

        String subjectId;
        do {
            subjectId = scanner.nextLine();

            if (subjectId.equals("0")) {
                return; // Return to main menu
            } else if (subjectId.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            } else {
                // Find the subject by ID
                Subject selectedSubject = findSubjectById(subjectId);

                if (selectedSubject != null) {
                    // Display the selected subject's information
                    System.out.println("\n----------------------------------------------------------------------------");
                    System.out.println("You selected " + selectedSubject.getId() + " | " + selectedSubject.getTitle() + ".");
                    System.out.println("\nSubject Information:");
                    System.out.println("Subject Title: " + selectedSubject.getTitle());
                    System.out.println("Subject Description: " + selectedSubject.getDescription());

                    // Prompt to edit or delete the selected subject
                    System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
                    System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
                    System.out.print("Type Here: ");
                    String choice = scanner.nextLine();

                    switch (choice.toUpperCase()) {
                        case "E":
                            // Edit the subject's information
                            editSubject(selectedSubject);
                            break;
                        case "D":
                            deleteSubject(selectedSubject);
                            break;
                        case "0":
                            return; // Return to main menu
                        case "EXIT":
                            System.out.println("Exiting...");
                            System.exit(0); // Exit the program
                        default:
                            System.out.println("\nInvalid input. Please try again.");
                    }
                } else {
                    System.out.println("Subject with ID " + subjectId + " not found. Please try again.");
                    System.out.print("Type Here: ");
                }
            }
        } while (true);
    }

    // Method to edit subject information
    private static void editSubject(Subject subject) {
        while (true) {
            System.out.println("\n----------------------------------------------------------------------------");
            System.out.println("You selected edit.\n");

            // Prompt user to enter new information
            System.out.print("Enter new Subject Title: ");
            String newTitle = scanner.nextLine();
            System.out.print("Enter new Subject Description: ");
            String newDescription = scanner.nextLine();

            // Update subject's information
            subject.setTitle(newTitle);
            subject.setDescription(newDescription);

            // Display updated information
            System.out.println("\n----------------------------------------------------------------------------");
            System.out.println("You successfully edited Subject.\n");
            System.out.println("Subject Title: " + newTitle);
            System.out.println("Subject Description: " + newDescription);

            // Prompt to return to main menu or exit
            System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
            System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
            System.out.print("Type Here: ");

            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("E") || input.equalsIgnoreCase("D")) {
                // If the input is valid (E or D), break the loop to proceed
                break;
            } else if (input.equals("0")) {
                // If the input is 0, return to the main menu
                return;
            } else if (input.equalsIgnoreCase("exit")) {
                // If the input is "exit", exit the program
                System.out.println("Exiting...");
                System.exit(0);
            } else {
                // If the input is invalid, display an error message and continue the loop
                System.out.println("\nInvalid input. Please try again.");
            }
        }
    }

    // Method to delete subject information
    private static void deleteSubject(Subject subject) {
        // Remove the subject from the list
        subjects.remove(subject);
        
        // Display a confirmation message
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("Subject deleted successfully.\n");
        
        // Prompt to return to main menu or exit
        System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
        System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");
    }


    // Method to view subjects enrolled by students
    private static void viewStudentSubjects() {
        System.out.println("\n\n----------------------------------------------------------------------------");
        System.out.println("You selected View Student subjects.\n");

        boolean subjectsFound = false;

        // Display enrolled subjects for each student
        for (Student student : students) {
            if (!student.getEnrolledSubjects().isEmpty()) {
                subjectsFound = true;
                System.out.println("Enrolled subjects for Student: " + student.getId() + " | " + student.getLastName() + ", " + student.getFirstName());
                for (String subjectId : student.getEnrolledSubjects()) {
                    // Find the subject object with the matching ID
                    Subject subject = findSubjectById(subjectId);
                    if (subject != null) {
                        System.out.println("ID: " + subject.getId());
                        System.out.println("Subject Title: " + subject.getTitle());
                        System.out.println("Subject Description: " + subject.getDescription());
                        System.out.println("\n===========================================================================\n");
                    }
                }
                // Prompt to enter the ID of the Subject to perform edit or delete
                System.out.println("\n>Enter the ID of the Subject to perform edit or delete.");
                System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
                System.out.print("Type Here: ");

                String subjectId;
                do {
                    subjectId = scanner.nextLine();

                    if (subjectId.equals("0")) {
                        return; // Return to main menu
                    } else if (subjectId.equalsIgnoreCase("exit")) {
                        System.out.println("Exiting...");
                        System.exit(0); // Exit the program
                    } else {
                        // Find the subject by ID
                        Subject selectedSubject = findSubjectById(subjectId);

                        if (selectedSubject != null) {
                            // Display the selected subject's information
                            System.out.println("\n----------------------------------------------------------------------------");
                            System.out.println("You selected " + selectedSubject.getId() + " | " + selectedSubject.getTitle() + ".");
                            System.out.println("\nSubject Information:");
                            System.out.println("Subject Title: " + selectedSubject.getTitle());
                            System.out.println("Subject Description: " + selectedSubject.getDescription());

                            // Prompt to edit or delete the selected subject
                            System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
                            System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
                            System.out.print("Type Here: ");
                            String choice = scanner.nextLine();

                            switch (choice.toUpperCase()) {
                                case "E":
                                    // Edit the subject's information
                                    editSubjectt(selectedSubject);
                                    break;
                                case "D":
                                    deleteSubjectt(selectedSubject);
                                    break;
                                case "0":
                                    return; // Return to main menu
                                case "EXIT":
                                    System.out.println("Exiting...");
                                    System.exit(0); // Exit the program
                                default:
                                    System.out.println("\nInvalid input. Please try again.");
                            }
                        } else {
                            System.out.println("Subject with ID " + subjectId + " not found. Please try again.");
                            System.out.print("Type Here: ");
                        }
                    }
                } while (true);
            }
        }

        if (!subjectsFound) {
            System.out.println("No subjects enrolled to any student.");
        }

        // Prompt to return to main menu or exit
        System.out.println("\n(Enter 0 to return to main menu, type \"exit\" if you wish to exit.)");

        String input;
        do {
            System.out.print("Type Here: ");
            input = scanner.nextLine();
            if (input.equals("0")) {
                return; // Return to main menu
            } else if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                System.exit(0); // Exit the program
            }
        } while (true);
    }

    // Method to edit subject information
    private static void editSubjectt(Subject subject) {
        while (true) {
            System.out.println("\n----------------------------------------------------------------------------");
            System.out.println("You selected edit.\n");

            // Prompt user to enter new information
            System.out.print("Enter new Subject Title: ");
            String newTitle = scanner.nextLine();
            System.out.print("Enter new Subject Description: ");
            String newDescription = scanner.nextLine();

            // Update subject's information
            subject.setTitle(newTitle);
            subject.setDescription(newDescription);

            // Display updated information
            System.out.println("\n----------------------------------------------------------------------------");
            System.out.println("You successfully edited Subject.\n");
            System.out.println("Subject Title: " + newTitle);
            System.out.println("Subject Description: " + newDescription);

            // Prompt to return to main menu or exit
            System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
            System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
            System.out.print("Type Here: ");

            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("E") || input.equalsIgnoreCase("D")) {
                // If the input is valid (E or D), break the loop to proceed
                break;
            } else if (input.equals("0")) {
                // If the input is 0, return to the main menu
                return;
            } else if (input.equalsIgnoreCase("exit")) {
                // If the input is "exit", exit the program
                System.out.println("Exiting...");
                System.exit(0);
            } else {
                // If the input is invalid, display an error message and continue the loop
                System.out.println("\nInvalid input. Please try again.");
            }
        }
    }

    // Method to delete subject information
    private static void deleteSubjectt(Subject subject) {
        // Remove the subject from the list
        subjects.remove(subject);
        
        // Display a confirmation message
        System.out.println("\n----------------------------------------------------------------------------");
        System.out.println("Subject deleted successfully.\n");
        
        // Prompt to return to main menu or exit
        System.out.println("\n>Enter \"E\" to perform edit or enter \"D\" to perform delete.");
        System.out.println("(NOTE: Enter 0 to return to the main menu, type \"exit\" to end the program)");
        System.out.print("Type Here: ");
    }



    // Method to capitalize the first letter of each word in a string
    public static String capitalizeFirstLetter(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        StringBuilder result = new StringBuilder();
        String[] words = str.trim().split("\\s+");
        for (String word : words) {
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1).toLowerCase()).append(" ");
            }
        }
        return result.toString().trim();
    }
}